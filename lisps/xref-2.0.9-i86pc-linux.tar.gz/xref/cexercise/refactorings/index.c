/*
            Index containing few refactoring examples.

  Put cursor on a function name and push F6 to move to the example.
*/


void renameSymbol();
void addRemoveParameter();
void extractFunction();


void refactoringIndex() {}

/*
  F5 will bring you back to main index.
*/
