#include <stdio.h>

/*
  1.) Select 'Xref -> Emacs IDE -> Compile File' to compile this file.

  2.) Select 'Xref -> Emacs IDE -> Run1' to run this program.

  3.) From now, you can invoke compile-run macro by pressing C-F8.
*/


void ideCompileAndRun() {}

int main(int argc, char **argv) {
    printf("hello world\n");
	return(0);
}

/*
  F5 will bring you back to Index; F7 closes windows
*/
