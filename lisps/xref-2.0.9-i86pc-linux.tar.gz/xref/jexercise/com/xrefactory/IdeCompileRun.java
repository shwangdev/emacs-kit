package com.xrefactory;

/*
  1.) Select 'Xref -> Emacs IDE -> Compile File' to compile this file.

  2.) Move cursor into class body and select 'Xref -> Emacs IDE -> Run
  This' to run this program.

  3.) From now, you can invoke compile-run macro by pressing C-F8, but
  do not forget to put cursor onto main method each time before.  
*/

class IdeCompileRun {
    public static void main(String[] args) {
        System.out.println("hello world");
    }
}

/*
  F5 will bring you back to Index
*/

